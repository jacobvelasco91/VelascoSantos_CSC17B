var aud = new Audio("./assets/sword.wav");
var ovr = new Audio("./assets/overworld.mp3");
ovr.loop = true;
ovr.volume = 0.1;
ovr.play();