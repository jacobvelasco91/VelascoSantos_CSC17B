# Resources
http://noproblo.dayjo.org/ZeldaSounds/
https://www.spriters-resource.com/snes/legendofzeldaalinktothepast/

# To Do:

## Almost Done
Map drawing - Mrinal
* Function to take map data and split out HTML
* All map tiles should be in one large `<div>`

Collision Detection / Physics - Harley
* Check if two bounding boxes have a collision

Animations - Eric
* An animation system so that we can do something like:
* `entity.anim.play("Walk");`

## Todo
Enemies
* Only need like 2-3
Attacking - Eric,
Inventory - Harley,
* Bomb, Bow, Potion
Heads Up Display,
Save/Loading,
* Just health, items (bomb, bow, potion), position, room
* Possibly map flags
Multiplayer,