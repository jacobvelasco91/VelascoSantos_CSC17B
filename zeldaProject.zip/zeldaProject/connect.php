<?php
$hn = "localhost";
$un = "root";
$pw = "";
$db = "blog";


 ?>
